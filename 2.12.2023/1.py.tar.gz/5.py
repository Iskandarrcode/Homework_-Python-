str = input("satr kiriting: ")
str = tuple(str)
print(str)